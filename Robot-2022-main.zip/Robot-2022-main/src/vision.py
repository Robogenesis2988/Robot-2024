#!/usr/bin/env python3
"""
    This is a good foundation to build your robot code on
"""

import wpilib


def cameraLaunch():
    wpilib.CameraServer.launch()
